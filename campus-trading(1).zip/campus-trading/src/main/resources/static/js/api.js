/**
 * 校园二手交易平台 - API工具类
 * Campus Second-hand Trading Platform
 */

const API_BASE = '';

const API = {
    // 封装请求
    async request(url, options = {}) {
        const config = {
            headers: { 'Content-Type': 'application/json' },
            ...options
        };

        // 自动添加 token
        const token = localStorage.getItem('token');
        if (token) {
            config.headers['Authorization'] = 'Bearer ' + token;
        }

        try {
            const response = await fetch(API_BASE + url, config);
            const data = await response.json();

            if (data.code === 401) {
                localStorage.removeItem('token');
                localStorage.removeItem('user');
                if (window.location.pathname !== '/login.html') {
                    window.location.href = '/login.html';
                }
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            return { code: 500, message: '网络错误，请重试' };
        }
    },

    get(url) {
        return this.request(url, { method: 'GET' });
    },

    post(url, data) {
        return this.request(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    },

    put(url, data) {
        return this.request(url, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },

    delete(url) {
        return this.request(url, { method: 'DELETE' });
    },

    // 文件上传
    async upload(file) {
        const formData = new FormData();
        formData.append('file', file);

        const token = localStorage.getItem('token');
        const headers = {};
        if (token) headers['Authorization'] = 'Bearer ' + token;

        try {
            const response = await fetch(API_BASE + '/api/file/upload', {
                method: 'POST',
                headers: headers,
                body: formData
            });
            return await response.json();
        } catch (error) {
            return { code: 500, message: '上传失败' };
        }
    }
};

// ===== Toast 提示 =====
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, 2500);
}

// ===== 登录状态检查 =====
function isLoggedIn() {
    return !!localStorage.getItem('token');
}

function getCurrentUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

// ===== 退出登录 =====
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login.html';
}

// ===== 渲染导航栏 =====
function renderNavbar() {
    const navbar = document.getElementById('navbar');
    if (!navbar) return;

    const user = getCurrentUser();
    const currentPath = window.location.pathname;

    const homeActive = currentPath === '/' || currentPath === '/index.html' ? 'style="color:#4CAF50;font-weight:bold"' : '';

    let userHtml = '';
    if (user) {
        userHtml = `
        <div class="nav-user">
            <span>👤 ${user.nickname || user.username}</span>
            <div class="dropdown">
                <a href="/personal.html">个人中心</a>
                <a href="/cart.html">🛒 购物车</a>
                <a href="/order.html">📋 我的订单</a>
                <a href="/message.html">💬 消息中心</a>
                <a href="/product-publish.html">📝 发布商品</a>
                <a href="#" onclick="logout()">退出登录</a>
            </div>
        </div>`;
    } else {
        userHtml = '<a href="/login.html" class="btn-login">登录 / 注册</a>';
    }

    navbar.innerHTML = `
    <div class="container">
        <a href="/" class="logo">🔄 校园二手交易</a>
        <ul class="nav-links">
            <li><a href="/" ${homeActive}>首页</a></li>
            <li><a href="/cart.html">🛒 购物车</a></li>
            ${user ? '<li><a href="/order.html">📋 订单</a></li>' : ''}
            ${userHtml}
        </ul>
    </div>`;
}

// ===== 页面加载时初始化 =====
document.addEventListener('DOMContentLoaded', () => {
    renderNavbar();
});
