-- ============================================
-- 校园二手交易平台 数据库脚本
-- Campus Second-hand Trading Platform
-- ============================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS campus_trading
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE campus_trading;

-- ============================================
-- 1. 用户表
-- ============================================
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
    `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    `password` VARCHAR(100) NOT NULL COMMENT '密码（MD5加密）',
    `nickname` VARCHAR(50) COMMENT '昵称',
    `avatar` VARCHAR(255) DEFAULT '/images/default-avatar.png' COMMENT '头像',
    `phone` VARCHAR(20) COMMENT '手机号',
    `email` VARCHAR(100) COMMENT '邮箱',
    `school` VARCHAR(100) COMMENT '学校',
    `role` VARCHAR(20) DEFAULT 'USER' COMMENT '角色: USER/ADMIN',
    `status` INT DEFAULT 0 COMMENT '状态: 0-正常, 1-禁用',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除: 0-未删除, 1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ============================================
-- 2. 商品分类表
-- ============================================
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '分类ID',
    `name` VARCHAR(50) NOT NULL COMMENT '分类名称',
    `icon` VARCHAR(255) COMMENT '图标',
    `parent_id` INT DEFAULT 0 COMMENT '父分类ID',
    `sort` INT DEFAULT 0 COMMENT '排序',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品分类表';

-- ============================================
-- 3. 商品表
-- ============================================
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '商品ID',
    `title` VARCHAR(200) NOT NULL COMMENT '商品标题',
    `description` TEXT COMMENT '商品描述',
    `category_id` INT COMMENT '分类ID',
    `price` DECIMAL(10,2) NOT NULL COMMENT '售价',
    `original_price` DECIMAL(10,2) COMMENT '原价',
    `images` VARCHAR(1000) COMMENT '商品图片（多张逗号分隔）',
    `condition` VARCHAR(20) COMMENT '成色: 全新/九成新/八成新/七成新及以下',
    `status` INT DEFAULT 1 COMMENT '状态: 1-在售, 2-已售, 3-已下架',
    `seller_id` INT COMMENT '卖家ID',
    `view_count` INT DEFAULT 0 COMMENT '浏览次数',
    `location` VARCHAR(200) COMMENT '交易地点',
    `contact_info` VARCHAR(100) COMMENT '联系方式',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除',
    INDEX idx_category_id (`category_id`),
    INDEX idx_seller_id (`seller_id`),
    INDEX idx_status (`status`),
    INDEX idx_title (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表';

-- ============================================
-- 4. 订单表
-- ============================================
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '订单ID',
    `order_no` VARCHAR(50) NOT NULL UNIQUE COMMENT '订单编号',
    `buyer_id` INT COMMENT '买家ID',
    `seller_id` INT COMMENT '卖家ID',
    `product_id` INT COMMENT '商品ID',
    `amount` DECIMAL(10,2) NOT NULL COMMENT '交易金额',
    `status` INT DEFAULT 1 COMMENT '状态: 1-待付款, 2-待发货, 3-待收货, 4-已完成, 5-已取消',
    `remark` VARCHAR(500) COMMENT '备注',
    `address` VARCHAR(300) COMMENT '交易地址',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除',
    INDEX idx_buyer_id (`buyer_id`),
    INDEX idx_seller_id (`seller_id`),
    INDEX idx_product_id (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ============================================
-- 5. 购物车表
-- ============================================
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '购物车ID',
    `user_id` INT COMMENT '用户ID',
    `product_id` INT COMMENT '商品ID',
    `quantity` INT DEFAULT 1 COMMENT '数量',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_user_id (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车表';

-- ============================================
-- 6. 消息表
-- ============================================
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '消息ID',
    `from_user_id` INT COMMENT '发送者ID',
    `to_user_id` INT COMMENT '接收者ID',
    `product_id` INT COMMENT '关联商品ID',
    `content` VARCHAR(1000) NOT NULL COMMENT '消息内容',
    `is_read` INT DEFAULT 0 COMMENT '0-未读, 1-已读',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_from_user (`from_user_id`),
    INDEX idx_to_user (`to_user_id`),
    INDEX idx_product (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息表';

-- ============================================
-- 7. 收藏表
-- ============================================
DROP TABLE IF EXISTS `favorite`;
CREATE TABLE `favorite` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '收藏ID',
    `user_id` INT COMMENT '用户ID',
    `product_id` INT COMMENT '商品ID',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_user_id (`user_id`),
    UNIQUE KEY uk_user_product (`user_id`, `product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收藏表';

-- ============================================
-- 8. 评论表
-- ============================================
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '评论ID',
    `user_id` INT COMMENT '用户ID',
    `product_id` INT COMMENT '商品ID',
    `order_id` INT COMMENT '订单ID',
    `content` VARCHAR(500) NOT NULL COMMENT '评论内容',
    `rating` INT DEFAULT 5 COMMENT '评分: 1-5',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_product_id (`product_id`),
    INDEX idx_user_id (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评论表';

-- ============================================
-- 插入初始数据
-- ============================================

-- 插入分类数据
INSERT INTO `category` (`name`, `icon`, `parent_id`, `sort`) VALUES
('教材教辅', '📚', 0, 1),
('电子数码', '💻', 0, 2),
('生活用品', '🏠', 0, 3),
('运动户外', '⚽', 0, 4),
('服饰鞋包', '👗', 0, 5),
('图书音像', '📖', 0, 6),
('其他', '📦', 0, 7);

-- 插入测试用户（密码为 123456 的MD5值）
INSERT INTO `user` (`username`, `password`, `nickname`, `phone`, `school`, `role`, `status`) VALUES
('admin', 'e10adc3949ba59abbe56e057f20f883e', '系统管理员', '13800000000', '某某大学', 'ADMIN', 0),
('zhangsan', 'e10adc3949ba59abbe56e057f20f883e', '张三', '13800000001', '某某大学', 'USER', 0),
('lisi', 'e10adc3949ba59abbe56e057f20f883e', '李四', '13800000002', '某某大学', 'USER', 0),
('wangwu', 'e10adc3949ba59abbe56e057f20f883e', '王五', '13800000003', '某某大学', 'USER', 0);

-- 插入测试商品数据
INSERT INTO `product` (`title`, `description`, `category_id`, `price`, `original_price`, `images`, `condition`, `status`, `seller_id`, `view_count`, `location`) VALUES
('高等数学（第七版）上册', '同济大学版高等数学，九成新，有少量笔记', 1, 25.00, 56.00, '/images/product1.jpg', '九成新', 1, 2, 120, '图书馆门口'),
('罗技K380蓝牙键盘', '罗技K380无线蓝牙键盘，使用三个月，功能正常', 2, 89.00, 199.00, '/images/product2.jpg', '八成新', 1, 3, 85, '3号宿舍楼下'),
('台灯LED护眼学习', '欧普LED护眼台灯，三档调光，用了一年', 3, 35.00, 89.00, '/images/product3.jpg', '八成新', 1, 2, 56, '食堂门口'),
('篮球斯伯丁', '斯伯丁正品篮球，七成新，气密性好', 4, 50.00, 169.00, '/images/product4.jpg', '七成新', 1, 3, 42, '体育馆'),
('华为FreeBuds 4i耳机', '华为无线蓝牙耳机，使用半年，续航正常', 2, 120.00, 399.00, '/images/product5.jpg', '九成新', 1, 4, 210, '图书馆门口'),
('大学英语四级真题', '星火英语四级真题，几乎全新无笔记', 1, 15.00, 49.80, '/images/product6.jpg', '全新', 1, 2, 88, '教学楼A区'),
('宿舍用小风扇', '桌面小风扇，USB充电款，静音设计', 3, 18.00, 45.00, '/images/product7.jpg', '八成新', 1, 3, 67, '2号宿舍楼下'),
('iPad Air 4 64G', 'iPad Air 4 64G WiFi版，屏幕完好，有原装充电器', 2, 2800.00, 4799.00, '/images/product8.jpg', '九成新', 1, 4, 356, '校门口');

-- 插入测试订单数据
INSERT INTO `order` (`order_no`, `buyer_id`, `seller_id`, `product_id`, `amount`, `status`, `address`) VALUES
('CT20250301120001A1B2', 3, 2, 1, 25.00, 4, '图书馆门口面交'),
('CT20250302150002C3D4', 4, 2, 5, 120.00, 3, '食堂门口面交'),
('CT20250303100003E5F6', 2, 3, 2, 89.00, 4, '3号宿舍楼下');
