package com.campus.trading.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.trading.entity.Message;

import java.util.List;

public interface MessageService extends IService<Message> {

    void sendMessage(Integer fromUserId, Integer toUserId, Integer productId, String content);

    List<Message> getMessages(Integer userId, Integer productId);

    List<Message> getUnreadMessages(Integer userId);

    void markAsRead(Integer messageId);
}
