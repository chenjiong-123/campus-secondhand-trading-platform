package com.campus.trading.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.trading.entity.Cart;
import com.campus.trading.entity.Product;
import com.campus.trading.mapper.CartMapper;
import com.campus.trading.mapper.ProductMapper;
import com.campus.trading.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CartServiceImpl extends ServiceImpl<CartMapper, Cart> implements CartService {

    @Autowired
    private ProductMapper productMapper;

    @Override
    public void addToCart(Integer userId, Integer productId) {
        // 检查是否已在购物车
        LambdaQueryWrapper<Cart> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Cart::getUserId, userId).eq(Cart::getProductId, productId);
        if (this.getOne(wrapper) != null) {
            return; // 已存在，不再重复添加
        }

        Cart cart = new Cart();
        cart.setUserId(userId);
        cart.setProductId(productId);
        cart.setQuantity(1);
        this.save(cart);
    }

    @Override
    public void removeFromCart(Integer userId, Integer cartId) {
        Cart cart = this.getById(cartId);
        if (cart != null && cart.getUserId().equals(userId)) {
            this.removeById(cartId);
        }
    }

    @Override
    public List<Map<String, Object>> getCartList(Integer userId) {
        LambdaQueryWrapper<Cart> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Cart::getUserId, userId);
        wrapper.orderByDesc(Cart::getCreateTime);
        List<Cart> cartList = this.list(wrapper);

        List<Map<String, Object>> result = new ArrayList<>();
        for (Cart cart : cartList) {
            Product product = productMapper.selectById(cart.getProductId());
            if (product != null) {
                Map<String, Object> item = new HashMap<>();
                item.put("cartId", cart.getId());
                item.put("product", product);
                item.put("quantity", cart.getQuantity());
                item.put("createTime", cart.getCreateTime());
                result.add(item);
            }
        }
        return result;
    }

    @Override
    public void clearCart(Integer userId) {
        LambdaQueryWrapper<Cart> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Cart::getUserId, userId);
        this.remove(wrapper);
    }
}
