package com.campus.trading.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.trading.entity.Product;
import com.campus.trading.mapper.ProductMapper;
import com.campus.trading.service.ProductService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductService {

    @Override
    public Page<Product> search(String keyword, Integer categoryId, Integer page, Integer size) {
        LambdaQueryWrapper<Product> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Product::getStatus, 1); // 只查在售商品

        if (StringUtils.hasText(keyword)) {
            wrapper.like(Product::getTitle, keyword);
        }
        if (categoryId != null && categoryId > 0) {
            wrapper.eq(Product::getCategoryId, categoryId);
        }
        wrapper.orderByDesc(Product::getCreateTime);

        return this.page(new Page<>(page, size), wrapper);
    }

    @Override
    public Page<Product> getMyProducts(Integer sellerId, Integer page, Integer size) {
        LambdaQueryWrapper<Product> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Product::getSellerId, sellerId);
        wrapper.orderByDesc(Product::getCreateTime);

        return this.page(new Page<>(page, size), wrapper);
    }

    @Override
    public Product getDetail(Integer productId) {
        Product product = this.getById(productId);
        if (product != null) {
            product.setViewCount(product.getViewCount() + 1);
            this.updateById(product);
        }
        return product;
    }

    @Override
    public void publish(Product product) {
        product.setStatus(1);
        product.setViewCount(0);
        this.save(product);
    }

    @Override
    public void updateStatus(Integer productId, Integer status) {
        Product product = this.getById(productId);
        if (product != null) {
            product.setStatus(status);
            this.updateById(product);
        }
    }

    @Override
    public Page<Product> getLatestProducts(Integer page, Integer size) {
        LambdaQueryWrapper<Product> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Product::getStatus, 1);
        wrapper.orderByDesc(Product::getCreateTime);

        return this.page(new Page<>(page, size), wrapper);
    }
}
