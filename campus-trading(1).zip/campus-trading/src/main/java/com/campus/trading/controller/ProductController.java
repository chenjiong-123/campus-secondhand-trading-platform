package com.campus.trading.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.campus.trading.common.Result;
import com.campus.trading.entity.Product;
import com.campus.trading.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/list")
    public Result<?> list(@RequestParam(defaultValue = "") String keyword,
                          @RequestParam(defaultValue = "0") Integer categoryId,
                          @RequestParam(defaultValue = "1") Integer page,
                          @RequestParam(defaultValue = "12") Integer size) {
        Page<Product> result = productService.search(keyword, categoryId, page, size);
        Map<String, Object> data = new HashMap<>();
        data.put("records", result.getRecords());
        data.put("total", result.getTotal());
        data.put("current", result.getCurrent());
        data.put("pages", result.getPages());
        return Result.success(data);
    }

    @GetMapping("/detail/{id}")
    public Result<?> detail(@PathVariable Integer id) {
        Product product = productService.getDetail(id);
        if (product == null) {
            return Result.error("商品不存在");
        }
        return Result.success(product);
    }

    @PostMapping("/publish")
    public Result<?> publish(HttpServletRequest request, @RequestBody Product product) {
        Integer userId = (Integer) request.getAttribute("userId");
        product.setSellerId(userId);
        productService.publish(product);
        return Result.success("发布成功", product);
    }

    @GetMapping("/my")
    public Result<?> myProducts(HttpServletRequest request,
                                @RequestParam(defaultValue = "1") Integer page,
                                @RequestParam(defaultValue = "12") Integer size) {
        Integer userId = (Integer) request.getAttribute("userId");
        Page<Product> result = productService.getMyProducts(userId, page, size);
        Map<String, Object> data = new HashMap<>();
        data.put("records", result.getRecords());
        data.put("total", result.getTotal());
        data.put("current", result.getCurrent());
        data.put("pages", result.getPages());
        return Result.success(data);
    }

    @PutMapping("/status/{id}")
    public Result<?> updateStatus(@PathVariable Integer id, @RequestBody Map<String, Integer> params) {
        Integer status = params.get("status");
        productService.updateStatus(id, status);
        return Result.success("更新成功");
    }

    @GetMapping("/latest")
    public Result<?> latest(@RequestParam(defaultValue = "1") Integer page,
                            @RequestParam(defaultValue = "8") Integer size) {
        Page<Product> result = productService.getLatestProducts(page, size);
        return Result.success(result.getRecords());
    }
}
