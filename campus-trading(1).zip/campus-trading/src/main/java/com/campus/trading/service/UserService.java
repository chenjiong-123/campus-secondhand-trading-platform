package com.campus.trading.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.trading.entity.User;

public interface UserService extends IService<User> {

    User register(String username, String password, String nickname, String phone, String school);

    String login(String username, String password);

    User getCurrentUser(Integer userId);

    void updateProfile(Integer userId, String nickname, String phone, String email, String avatar);
}
