package com.campus.trading.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.trading.entity.Product;

public interface ProductService extends IService<Product> {

    Page<Product> search(String keyword, Integer categoryId, Integer page, Integer size);

    Page<Product> getMyProducts(Integer sellerId, Integer page, Integer size);

    Product getDetail(Integer productId);

    void publish(Product product);

    void updateStatus(Integer productId, Integer status);

    Page<Product> getLatestProducts(Integer page, Integer size);
}
