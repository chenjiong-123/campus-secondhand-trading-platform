package com.campus.trading.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.trading.entity.Order;
import com.campus.trading.entity.Product;
import com.campus.trading.mapper.OrderMapper;
import com.campus.trading.mapper.ProductMapper;
import com.campus.trading.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {

    @Autowired
    private ProductMapper productMapper;

    @Override
    @Transactional
    public Order createOrder(Integer buyerId, Integer productId, String remark, String address) {
        Product product = productMapper.selectById(productId);
        if (product == null || product.getStatus() != 1) {
            throw new RuntimeException("商品不存在或已售出");
        }

        // 生成订单编号
        String orderNo = "CT" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
                + UUID.randomUUID().toString().substring(0, 4).toUpperCase();

        Order order = new Order();
        order.setOrderNo(orderNo);
        order.setBuyerId(buyerId);
        order.setSellerId(product.getSellerId());
        order.setProductId(productId);
        order.setAmount(product.getPrice());
        order.setStatus(1);
        order.setRemark(remark);
        order.setAddress(address);

        this.save(order);

        // 更新商品状态
        product.setStatus(2); // 已售
        productMapper.updateById(product);

        return order;
    }

    @Override
    public Page<Order> getBuyOrders(Integer buyerId, Integer page, Integer size) {
        LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Order::getBuyerId, buyerId);
        wrapper.orderByDesc(Order::getCreateTime);

        return this.page(new Page<>(page, size), wrapper);
    }

    @Override
    public Page<Order> getSellOrders(Integer sellerId, Integer page, Integer size) {
        LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Order::getSellerId, sellerId);
        wrapper.orderByDesc(Order::getCreateTime);

        return this.page(new Page<>(page, size), wrapper);
    }

    @Override
    public void updateOrderStatus(Integer orderId, Integer status, Integer userId) {
        Order order = this.getById(orderId);
        if (order == null) {
            throw new RuntimeException("订单不存在");
        }

        // 验证权限
        if (status == 3 || status == 5) { // 确认收货或取消 -> 买家操作
            if (!order.getBuyerId().equals(userId)) {
                throw new RuntimeException("无权操作此订单");
            }
        } else if (status == 2 || status == 4) { // 发货 -> 卖家操作
            if (!order.getSellerId().equals(userId)) {
                throw new RuntimeException("无权操作此订单");
            }
        }

        order.setStatus(status);
        this.updateById(order);
    }

    @Override
    public Order getOrderDetail(Integer orderId) {
        return this.getById(orderId);
    }
}
