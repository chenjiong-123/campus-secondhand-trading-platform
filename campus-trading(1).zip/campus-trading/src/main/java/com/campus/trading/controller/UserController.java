package com.campus.trading.controller;

import com.campus.trading.common.Result;
import com.campus.trading.entity.User;
import com.campus.trading.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public Result<?> register(@RequestBody Map<String, String> params) {
        try {
            User user = userService.register(
                    params.get("username"),
                    params.get("password"),
                    params.get("nickname"),
                    params.get("phone"),
                    params.get("school")
            );
            return Result.success("注册成功", user);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/login")
    public Result<?> login(@RequestBody Map<String, String> params) {
        try {
            String token = userService.login(
                    params.get("username"),
                    params.get("password")
            );
            Map<String, String> data = new HashMap<>();
            data.put("token", token);
            return Result.success("登录成功", data);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/info")
    public Result<?> getUserInfo(HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        User user = userService.getCurrentUser(userId);
        if (user != null) {
            user.setPassword(null); // 不返回密码
        }
        return Result.success(user);
    }

    @PutMapping("/profile")
    public Result<?> updateProfile(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Integer userId = (Integer) request.getAttribute("userId");
        userService.updateProfile(
                userId,
                params.get("nickname"),
                params.get("phone"),
                params.get("email"),
                params.get("avatar")
        );
        return Result.success("更新成功");
    }
}
