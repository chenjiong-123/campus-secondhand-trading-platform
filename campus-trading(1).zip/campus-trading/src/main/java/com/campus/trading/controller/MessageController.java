package com.campus.trading.controller;

import com.campus.trading.common.Result;
import com.campus.trading.entity.Message;
import com.campus.trading.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/message")
public class MessageController {

    @Autowired
    private MessageService messageService;

    @PostMapping("/send")
    public Result<?> send(HttpServletRequest request, @RequestBody Map<String, Object> params) {
        Integer fromUserId = (Integer) request.getAttribute("userId");
        Integer toUserId = (Integer) params.get("toUserId");
        Integer productId = (Integer) params.get("productId");
        String content = (String) params.get("content");

        messageService.sendMessage(fromUserId, toUserId, productId, content);
        return Result.success("发送成功");
    }

    @GetMapping("/list")
    public Result<?> list(HttpServletRequest request,
                          @RequestParam(required = false) Integer productId) {
        Integer userId = (Integer) request.getAttribute("userId");
        List<Message> messages = messageService.getMessages(userId, productId);
        return Result.success(messages);
    }

    @GetMapping("/unread")
    public Result<?> unread(HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        List<Message> messages = messageService.getUnreadMessages(userId);
        return Result.success(messages);
    }

    @PutMapping("/read/{id}")
    public Result<?> markRead(@PathVariable Integer id) {
        messageService.markAsRead(id);
        return Result.success("已标记为已读");
    }
}
