package com.campus.trading.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.campus.trading.common.Result;
import com.campus.trading.entity.Order;
import com.campus.trading.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public Result<?> create(HttpServletRequest request, @RequestBody Map<String, Object> params) {
        try {
            Integer userId = (Integer) request.getAttribute("userId");
            Integer productId = (Integer) params.get("productId");
            String remark = (String) params.getOrDefault("remark", "");
            String address = (String) params.getOrDefault("address", "");

            Order order = orderService.createOrder(userId, productId, remark, address);
            return Result.success("下单成功", order);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/buy")
    public Result<?> buyOrders(HttpServletRequest request,
                               @RequestParam(defaultValue = "1") Integer page,
                               @RequestParam(defaultValue = "10") Integer size) {
        Integer userId = (Integer) request.getAttribute("userId");
        Page<Order> result = orderService.getBuyOrders(userId, page, size);
        Map<String, Object> data = new HashMap<>();
        data.put("records", result.getRecords());
        data.put("total", result.getTotal());
        data.put("current", result.getCurrent());
        data.put("pages", result.getPages());
        return Result.success(data);
    }

    @GetMapping("/sell")
    public Result<?> sellOrders(HttpServletRequest request,
                                @RequestParam(defaultValue = "1") Integer page,
                                @RequestParam(defaultValue = "10") Integer size) {
        Integer userId = (Integer) request.getAttribute("userId");
        Page<Order> result = orderService.getSellOrders(userId, page, size);
        Map<String, Object> data = new HashMap<>();
        data.put("records", result.getRecords());
        data.put("total", result.getTotal());
        data.put("current", result.getCurrent());
        data.put("pages", result.getPages());
        return Result.success(data);
    }

    @PutMapping("/status/{id}")
    public Result<?> updateStatus(HttpServletRequest request,
                                  @PathVariable Integer id,
                                  @RequestBody Map<String, Integer> params) {
        try {
            Integer userId = (Integer) request.getAttribute("userId");
            Integer status = params.get("status");
            orderService.updateOrderStatus(id, status, userId);
            return Result.success("操作成功");
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/detail/{id}")
    public Result<?> detail(@PathVariable Integer id) {
        Order order = orderService.getOrderDetail(id);
        if (order == null) {
            return Result.error("订单不存在");
        }
        return Result.success(order);
    }
}
