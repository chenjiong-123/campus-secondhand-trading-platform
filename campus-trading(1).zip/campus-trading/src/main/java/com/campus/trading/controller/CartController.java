package com.campus.trading.controller;

import com.campus.trading.common.Result;
import com.campus.trading.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public Result<?> add(HttpServletRequest request, @RequestBody Map<String, Integer> params) {
        Integer userId = (Integer) request.getAttribute("userId");
        Integer productId = params.get("productId");
        cartService.addToCart(userId, productId);
        return Result.success("已加入购物车");
    }

    @GetMapping("/list")
    public Result<?> list(HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        List<Map<String, Object>> cartList = cartService.getCartList(userId);
        return Result.success(cartList);
    }

    @DeleteMapping("/remove/{id}")
    public Result<?> remove(HttpServletRequest request, @PathVariable Integer id) {
        Integer userId = (Integer) request.getAttribute("userId");
        cartService.removeFromCart(userId, id);
        return Result.success("已移除");
    }

    @DeleteMapping("/clear")
    public Result<?> clear(HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        cartService.clearCart(userId);
        return Result.success("购物车已清空");
    }
}
