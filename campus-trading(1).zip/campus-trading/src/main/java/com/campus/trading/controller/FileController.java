package com.campus.trading.controller;

import com.campus.trading.common.Result;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.*;

@RestController
@RequestMapping("/api/file")
public class FileController {

    @Value("${file.upload.path}")
    private String uploadPath;

    @PostMapping("/upload")
    public Result<?> upload(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return Result.error("请选择文件");
        }

        try {
            // 生成唯一文件名
            String originalName = file.getOriginalFilename();
            String suffix = "";
            if (originalName != null && originalName.contains(".")) {
                suffix = originalName.substring(originalName.lastIndexOf("."));
            }
            String fileName = UUID.randomUUID().toString() + suffix;

            // 确保目录存在
            File dir = new File(uploadPath);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            // 保存文件
            File dest = new File(uploadPath + fileName);
            file.transferTo(dest);

            Map<String, String> data = new HashMap<>();
            data.put("fileName", fileName);
            data.put("url", "/uploads/" + fileName);
            return Result.success("上传成功", data);
        } catch (IOException e) {
            return Result.error("上传失败: " + e.getMessage());
        }
    }

    @PostMapping("/uploads")
    public Result<?> multiUpload(@RequestParam("files") MultipartFile[] files) {
        List<Map<String, String>> result = new ArrayList<>();
        for (MultipartFile file : files) {
            try {
                String originalName = file.getOriginalFilename();
                String suffix = "";
                if (originalName != null && originalName.contains(".")) {
                    suffix = originalName.substring(originalName.lastIndexOf("."));
                }
                String fileName = UUID.randomUUID().toString() + suffix;

                File dir = new File(uploadPath);
                if (!dir.exists()) dir.mkdirs();

                File dest = new File(uploadPath + fileName);
                file.transferTo(dest);

                Map<String, String> data = new HashMap<>();
                data.put("fileName", fileName);
                data.put("url", "/uploads/" + fileName);
                result.add(data);
            } catch (IOException e) {
                // skip failed files
            }
        }
        return Result.success("上传完成", result);
    }
}
