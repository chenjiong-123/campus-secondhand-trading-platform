package com.campus.trading.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.trading.entity.Order;

public interface OrderService extends IService<Order> {

    Order createOrder(Integer buyerId, Integer productId, String remark, String address);

    Page<Order> getBuyOrders(Integer buyerId, Integer page, Integer size);

    Page<Order> getSellOrders(Integer sellerId, Integer page, Integer size);

    void updateOrderStatus(Integer orderId, Integer status, Integer userId);

    Order getOrderDetail(Integer orderId);
}
