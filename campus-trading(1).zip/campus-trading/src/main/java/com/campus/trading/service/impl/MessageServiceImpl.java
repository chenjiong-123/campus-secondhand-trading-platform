package com.campus.trading.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.trading.entity.Message;
import com.campus.trading.mapper.MessageMapper;
import com.campus.trading.service.MessageService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageServiceImpl extends ServiceImpl<MessageMapper, Message> implements MessageService {

    @Override
    public void sendMessage(Integer fromUserId, Integer toUserId, Integer productId, String content) {
        Message message = new Message();
        message.setFromUserId(fromUserId);
        message.setToUserId(toUserId);
        message.setProductId(productId);
        message.setContent(content);
        message.setIsRead(0);
        this.save(message);
    }

    @Override
    public List<Message> getMessages(Integer userId, Integer productId) {
        LambdaQueryWrapper<Message> wrapper = new LambdaQueryWrapper<>();
        wrapper.and(w -> w.eq(Message::getFromUserId, userId).or().eq(Message::getToUserId, userId));
        if (productId != null) {
            wrapper.eq(Message::getProductId, productId);
        }
        wrapper.orderByAsc(Message::getCreateTime);
        return this.list(wrapper);
    }

    @Override
    public List<Message> getUnreadMessages(Integer userId) {
        LambdaQueryWrapper<Message> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Message::getToUserId, userId).eq(Message::getIsRead, 0);
        wrapper.orderByDesc(Message::getCreateTime);
        return this.list(wrapper);
    }

    @Override
    public void markAsRead(Integer messageId) {
        Message message = this.getById(messageId);
        if (message != null) {
            message.setIsRead(1);
            this.updateById(message);
        }
    }
}
