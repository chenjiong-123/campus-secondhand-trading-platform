package com.campus.trading.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.trading.entity.Cart;

import java.util.List;
import java.util.Map;

public interface CartService extends IService<Cart> {

    void addToCart(Integer userId, Integer productId);

    void removeFromCart(Integer userId, Integer cartId);

    List<Map<String, Object>> getCartList(Integer userId);

    void clearCart(Integer userId);
}
