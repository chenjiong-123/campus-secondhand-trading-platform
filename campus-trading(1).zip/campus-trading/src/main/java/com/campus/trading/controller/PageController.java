package com.campus.trading.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 页面路由控制器
 */
@Controller
public class PageController {

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/login.html")
    public String login() {
        return "login";
    }

    @GetMapping("/register.html")
    public String register() {
        return "register";
    }

    @GetMapping("/product-detail.html")
    public String productDetail() {
        return "product-detail";
    }

    @GetMapping("/product-publish.html")
    public String productPublish() {
        return "product-publish";
    }

    @GetMapping("/cart.html")
    public String cart() {
        return "cart";
    }

    @GetMapping("/order.html")
    public String order() {
        return "order";
    }

    @GetMapping("/personal.html")
    public String personal() {
        return "personal";
    }

    @GetMapping("/message.html")
    public String message() {
        return "message";
    }
}
